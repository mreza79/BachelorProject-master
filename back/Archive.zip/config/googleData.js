module.exports.clientId = "450834690368-3u0t5a1k0aai1q7o3mc9q1acdfgpihb4.apps.googleusercontent.com"
module.exports.clientSecret = "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"